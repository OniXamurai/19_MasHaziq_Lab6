﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CalculatorScript : MonoBehaviour
{
    //Haziq Do EUROS AND AUSTRALIAN Currency
    //Ben Do USD + Yen
    //Tim Do ...
    public float Amount;
    public float SGDEURO = 0.70f;
    public float SGDAUS = 1.09f;
    public float SGDUSD = 0.74f;
    public float SGDJPY = 97.20f;

    public Toggle EURO;
    public Toggle AUS;
    public Toggle USD;
    public Toggle JPY;

    public InputField InputAmount;
    public InputField InputConverted;

    // Start is called before the first frame update
    void Start()
    {
        EURO.isOn = false;
        AUS.isOn = false;
        USD.isOn = false;
        JPY.isOn = false;
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void Conversion()
    {
        float Amount = float.Parse(InputAmount.text);

        if (EURO.isOn == true)
        {
            AUS.isOn = false;
            USD.isOn = false;
            JPY.isOn = false;

            InputConverted.text = "EURO " + (Amount * SGDEURO);
        }
        else if (AUS.isOn == true)
        {
            EURO.isOn = false;
            USD.isOn = false;
            JPY.isOn = false;

            InputConverted.text = "AUS " + (Amount * SGDAUS);
        }
        else if (USD.isOn == true)
		{
            JPY.isOn = false;
            EURO.isOn = false;
            AUS.isOn = false;

            InputConverted.text = "$ " + (Amount * SGDUSD);
        }
        else if (JPY.isOn == true)
		{
            EURO.isOn = false;
            AUS.isOn = false;
            USD.isOn = false;


            InputConverted.text = "¥ " + (Amount * SGDJPY);
        }
    }

    public void Clear()
    {
        EURO.isOn = false;
        AUS.isOn = false;
        USD.isOn = false;
        JPY.isOn = false;

        InputAmount.text = " ";
        InputConverted.text = " ";
    }
}