﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CalculatorScript : MonoBehaviour
{
    //Haziq Do EUROS AND AUSTRALIAN Currency
    //Ben Do ...
    //Tim Do ...
    public float Amount;
    public float SGDEURO = 0.70f;
    public float SGDAUS = 1.09f;

    public Toggle EURO;
    public Toggle AUS;

    public InputField InputAmount;
    public InputField InputConverted;

    // Start is called before the first frame update
    void Start()
    {
        EURO.isOn = false;
        AUS.isOn = false;
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void Conversion()
    {
        float Amount = float.Parse(InputAmount.text);

        if (EURO.isOn == true)
        {
            AUS.isOn = false;

            InputConverted.text = "EURO " + (Amount * SGDEURO);
        }
        else if (AUS.isOn == true)
        {
            EURO.isOn = false;

            InputConverted.text = "AUS " + (Amount * SGDAUS);
        }
    }

    public void Clear()
    {
        EURO.isOn = false;
        AUS.isOn = false;

        InputAmount.text = " ";
        InputConverted.text = " ";
    }
}